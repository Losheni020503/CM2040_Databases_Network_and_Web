const express = require('express');
const router = express.Router();
const authorEmail = "author@onlyblog.com"; // hard coded 'author' email instead of making roles as there is only 1 author.

// Middleware to check if the user is an author
function checkAuthorAccess(req, res, next) {
    if (req.session.user && req.session.user.role === 'author') {
        next();
    } else {
        res.redirect('/login');
    }
}

// Render Author Home Page
router.get('/', checkAuthorAccess, (req, res) => {
    let articleQuery = 'SELECT * FROM Articles ORDER BY title';
    let blogQuery = `
        SELECT Blog.Title AS blogTitle, Blog.Subtitle AS blogSubtitle, Blog.author AS authorName
        FROM Blog
        WHERE Blog.id = 1
    `;

    db.all(articleQuery, [], (err, articles) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        const publishedArticles = articles.filter(article => article.isPublished);
        const draftArticles = articles.filter(article => !article.isPublished);

        db.get(blogQuery, [], (err, blog) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Internal Server Error');
            }

            if (!blog){
                blog = ['','',''];
            }

            // Render the page with article and blog information
            res.render('authorhome', { 
                blog: blog, 
                articles: articles, 
                publishedArticles: publishedArticles, 
                draftArticles: draftArticles 
            });
        });
    });
});

// Author's Settings Page
router.get('/setting', checkAuthorAccess, (req, res) => {
    const query = `
        SELECT Blog.Title AS blogTitle, Blog.Subtitle AS blogSubtitle, Blog.author AS authorName
        FROM Blog
        WHERE Blog.id = 1
    `;

    db.get(query, (err, row) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        // To check if the blog exists, if not to return empty placeholders
        if (!row) {
            row = ['',''];
        }

        const { blogTitle, blogSubtitle } = row;
        res.render('authorsetting', { blogTitle, blogSubtitle });
    });
});

router.post('/setting/update', checkAuthorAccess, (req, res) => {
    const { blogTitle, blogSubtitle } = req.body;
    const authorName = req.session.user.name;
    let query = `
        UPDATE Blog
        SET Title = ?, Subtitle = ?, author = ?
        WHERE id = 1
    `;

    db.run(query, [blogTitle, blogSubtitle, authorName], function(err) {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }

        if (this.changes === 0) {
            query = `
                INSERT INTO Blog (id, Title, Subtitle, author)
                VALUES (?, ?, ?, ?)
            `;

            db.run(query, [1, blogTitle, blogSubtitle, authorName], function(err) {
                if (err) {
                    console.error(err);
                    return res.status(500).send('Internal Server Error');
                }

                res.redirect('/author');
            });
        } else {
            res.redirect('/author');
        }
    });
});

// Author's Article 
router.get('/article/:articleId?', checkAuthorAccess, (req, res) => {
    const articleId = req.params.articleId;
    const loggedInAuthorName = req.session.user.name;

    if (articleId) {
        db.get('SELECT * FROM Articles WHERE id = ? AND author = ?', [articleId, loggedInAuthorName], (err, row) => {
            if (err) {
                console.error(err);
                return res.status(500).send('Internal Server Error');
            }

            if (!row) { 
                return res.status(404).send('Article not found');
            }

            res.render('authorarticle', {
                articleId: row.id,
                articleTitle: row.title,
                articleSubtitle: row.subtitle,
                articleText: row.content,
                articleAuthor: row.author,
                articleCreation: row.createdAt
            });
        });
    } else {
        res.render('authorarticle', {
            articleId: null,
            articleTitle: '',
            articleSubtitle: '',
            articleText: '',
            articleAuthor: loggedInAuthorName,
            articleCreation: new Date(),
        });
    }
});

// Handle AJAX request for deleting an article
router.post('/delete', checkAuthorAccess, async (req, res) => {
    const articleId = req.body.articleId;

    try {
        // Delete the article from the database
        await db.run('DELETE FROM Articles WHERE id = ?', [articleId]);
        res.json({ success: true });
    } catch (error) {
        console.error(error.message);
        res.json({ success: false, message: 'Error deleting article' });
    }
});

// Handle AJAX request for updating or creating an article
router.post('/article/:action/:id?', checkAuthorAccess, async (req, res) => {
    const action = req.params.action;
    const articleId = req.params.id;
    const authorName = req.session.user.name;

    // Handle article update and creation logic
    try {
        if (action === 'update') {
            // Update existing article
            const updateSql = `
                UPDATE Articles 
                SET title = ?, content = ?, lastModified = ? 
                WHERE id = ? AND author = ?
            `;
            await db.run(updateSql, [req.body.articleTitle, req.body.articleText, new Date(), articleId, authorName]);
        } else if (action === 'create') {
            // Create a new article
            const insertSql = `
                INSERT INTO Articles (title, content, author, createdAt, lastModified, isPublished, likes, publicationDate) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `;
            const data = [
                req.body.articleTitle,
                req.body.articleText,
                authorName,
                new Date(),
                new Date(),
                0,
                0,
                null
            ];
            await db.run(insertSql, data);
        }

        res.redirect('/author');
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Internal Server Error');
    }

    // New route for creating a new draft article
router.get('/article/new', (req, res) => {
    res.render('author/article-edit', {
        title: 'Create New Draft Article',
        article: new Article(),
    });
});

});

module.exports = router;

