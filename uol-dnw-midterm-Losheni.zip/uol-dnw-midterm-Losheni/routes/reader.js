const express = require('express');
const router = express.Router();
// check if the user is logged in
function checkUserAccess(req, res, next) {
    if (req.session.user != '') {
        next();
    } else {
        res.redirect('/login');
    }
}

// Reader Home Page 
router.get('/', (req, res) => {
    let sql = 'SELECT * FROM Articles WHERE isPublished = 1 ORDER BY publicationDate DESC';
    let articles = [];

    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        }
        articles = rows;

        res.render('readerhome', { articles: articles });
    });
});

// Reader Article 
router.get('/article/:id', checkUserAccess, (req, res) => {
    const _articleId = req.params.id;
    const sqlArticle = 'SELECT * FROM Articles WHERE id = ?';
    const sqlComments = `SELECT Comments.*, userLoginInfo.user_name AS username FROM Comments JOIN userLoginInfo ON Comments.UserId = userLoginInfo.user_id WHERE ArticleId = ? ORDER BY createdAt DESC`;
    
    let _userId = null;
    if(req.session.user) {
        _userId = req.session.user.id;
    }
    
    const sqlLike = _userId ? `SELECT * FROM Likes WHERE ArticleId = ? AND UserId = ?` : null;

    db.get(sqlArticle, [_articleId], (err, row) => {
        if (err) {
            return console.error(err.message);
        }

        if (row) {
            row.articleCreation = `This article was created on ${new Date(row.createdAt).toLocaleDateString()}`;

            db.all(sqlComments, [_articleId], (err, comments) => {
                if (err) {
                    console.log('error9');
                    return console.error(err.message);
                }

                if(_userId && sqlLike) {
                    db.get(sqlLike, [_articleId, _userId], function(err, like) {
                        if (err) {
                            console.log('error99');
                            return console.error(err.message);
                        }
                        res.render('readerarticle', { 
                            article: row, 
                            comments, 
                            userHasLiked: like != null 
                        });
                    });
                } else {
                    res.render('readerarticle', { 
                        article: row, 
                        comments, 
                        userHasLiked: false 
                    });
                }
            });
        } else {
            res.redirect('/reader');
        }
    });
});

// Handle AJAX request for liking an article
router.post('/article/:id/like', async (req, res) => {
    const articleId = req.params.id;
    const userId = req.session.user.id;

    try {
        // Check if the user has already liked the article
        const likeCheckSql = 'SELECT * FROM Likes WHERE ArticleId = ? AND UserId = ?';
        const likeCheckResult = await db.get(likeCheckSql, [articleId, userId]);

        if (likeCheckResult) {
            // User has already liked the article, unlike it
            const unlikeSql = 'DELETE FROM Likes WHERE ArticleId = ? AND UserId = ?';
            await db.run(unlikeSql, [articleId, userId]);
            res.json({ liked: false });
        } else {
            // User has not liked the article, like it
            const likeSql = 'INSERT INTO Likes (ArticleId, UserId) VALUES (?, ?)';
            await db.run(likeSql, [articleId, userId]);
            res.json({ liked: true });
        }
    } catch (error) {
        console.error(error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Handle AJAX request for adding a comment to an article
router.post('/article/:id/comment', async (req, res) => {
    const articleId = req.params.id;
    const userId = req.session.user.id;
    const comment = req.body.commentText;

    try {
        // Insert the new comment into the database
        const commentSql = `
            INSERT INTO Comments (comments, createdAt, lastModified, ArticleId, UserId) 
            VALUES (?, ?, ?, ?, ?)
        `;
        const now = new Date().toISOString();
        await db.run(commentSql, [comment, now, now, articleId, userId]);

        res.json({ success: true });
    } catch (error) {
        console.error(error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

module.exports = router;
